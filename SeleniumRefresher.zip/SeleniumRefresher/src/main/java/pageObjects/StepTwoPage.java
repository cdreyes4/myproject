package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class StepTwoPage {

    protected WebDriver driver;

    private static final String SUBTITLE_XPATH_TEXT = "//span[@class='sub-title']";

    public StepTwoPage(WebDriver driver){
        this.driver = driver;
    }

    public String getPageSubTitle(){
        return driver.findElement(By.xpath(SUBTITLE_XPATH_TEXT)).getText();
    }
}
