package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class StepOnePage {

    protected WebDriver driver;

    private static final String FIRST_NAME_XPATH_TXBX = "//input[@id='firstName']";
    private static final String LAST_NAME_XPATH_TXBX = "//input[@id='lastName']";
    private static final String EMAIL_ADDRESS_XPATH_TXBX =  "//input[@id='email']";
    private static final String DATE_OF_BIRTH_MONTH_XPATH_DRPDOWN = "//select[@id='birthMonth']";
    private static final String DATE_OF_BIRTH_DAY_XPATH_DRPDOWN = "//select[@id='birthDay']";
    private static final String DATE_OF_BIRTH_YEAR_XPATH_DRPDOWN = "//select[@id='birthYear']";
    private static final String NEXT_LOCATION_XPATH_BTN = "//a[@class='btn btn-blue']";
    private static final String SUBTITLE_XPATH_TEXT = "//span[@class='sub-title']";
    private static final String ERR_MESSAGE_INVALID_EMAIL_XPATH_TXT = "//span[@id='emailError']";


    public StepOnePage(WebDriver driver){
        this.driver = driver;
    }

    public String getPageSubTitle(){
        return driver.findElement(By.xpath(SUBTITLE_XPATH_TEXT)).getText();
    }

    public void enterFirstName(String text){
        driver.findElement(By.xpath(FIRST_NAME_XPATH_TXBX)).sendKeys(text);
    }

    public void enterLastName(String text){
        driver.findElement(By.xpath(LAST_NAME_XPATH_TXBX)).sendKeys(text);
    }

    public void enterEmailAddress(String text){
        driver.findElement(By.xpath(EMAIL_ADDRESS_XPATH_TXBX)).sendKeys(text);
    }

    public void selectDateOfBirth(String month, String day, String year){
        Select m = new Select(driver.findElement(By.xpath(DATE_OF_BIRTH_MONTH_XPATH_DRPDOWN)));
        Select d = new Select(driver.findElement(By.xpath(DATE_OF_BIRTH_DAY_XPATH_DRPDOWN)));
        Select y = new Select(driver.findElement(By.xpath(DATE_OF_BIRTH_YEAR_XPATH_DRPDOWN)));

        m.selectByVisibleText(month);
        d.selectByVisibleText(day);
        y.selectByVisibleText(year);
    }

    public void clickNexLocationButton(){
        driver.findElement(By.xpath(NEXT_LOCATION_XPATH_BTN)).click();
    }

    public String validateErrorMessage(){
        return driver.findElement(By.xpath(ERR_MESSAGE_INVALID_EMAIL_XPATH_TXT)).getText();
    }
}
