package mytest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import pageObjects.StepOnePage;
import pageObjects.StepTwoPage;

import static org.testng.Assert.*;

import java.util.concurrent.TimeUnit;

public class TestSubmitSuccess {

    @Test
    public void submit_Step_One(){

        String subtitle_text_step1 = "Tell us about yourself";
        String subtitle_text_step2 = "Add your address";

        System.setProperty("webdriver.gecko.driver", "C:\\01_MyFiles\\SeleniumRefresher\\driver\\geckodriver.exe");
        WebDriver driver = new FirefoxDriver();
        driver.get("https://www.utest.com/signup/personal");

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        StepOnePage pageOne = new StepOnePage(driver);

        assertEquals(pageOne.getPageSubTitle(), subtitle_text_step1);
        pageOne.enterFirstName("Cheryl");
        pageOne.enterLastName("Reyes");
        pageOne.enterEmailAddress("cheryl.reyes@yahoo.com");
        pageOne.selectDateOfBirth("December", "24", "1984");
        pageOne.clickNexLocationButton();

        StepTwoPage pageTwo = new StepTwoPage(driver);
        assertEquals(pageTwo.getPageSubTitle(), subtitle_text_step2);

        driver.close();
    }
}
