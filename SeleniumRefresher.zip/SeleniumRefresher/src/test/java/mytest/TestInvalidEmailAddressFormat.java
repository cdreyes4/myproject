package mytest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import pageObjects.StepOnePage;

import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertEquals;

public class TestInvalidEmailAddressFormat {

    @Test
    public void testInvalidEmailAddress(){

        String subtitle_text_step1 = "Tell us about yourself";
        String error_msg = "Enter valid email";

        System.setProperty("webdriver.gecko.driver", "C:\\01_MyFiles\\SeleniumRefresher\\driver\\geckodriver.exe");
        WebDriver driver = new FirefoxDriver();
        driver.get("https://www.utest.com/signup/personal");

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        StepOnePage pageOne = new StepOnePage(driver);

        assertEquals(pageOne.getPageSubTitle(), subtitle_text_step1);
        pageOne.enterFirstName("Cheryl");
        pageOne.enterLastName("Reyes");
        pageOne.enterEmailAddress("cheryl.reyesyahoo.com");
        pageOne.selectDateOfBirth("December", "24", "1984");
        pageOne.clickNexLocationButton();

        assertEquals(pageOne.validateErrorMessage(), error_msg);

        driver.close();

    }

}
